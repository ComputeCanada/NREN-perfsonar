<?php
$IPINFO_APIKEY=""; //put your token between the quotes if you have one
?>